سوق الجملة — نسخة PWA جاهزة للتحويل إلى APK

المحتويات:
- index.html : صفحة الدخول الرئيسية عند رفع الملفات على الاستضافة.
- souq-aljumla.html : نسخة التطبيق الأصلية مع ربط Google Sheets الموجود مسبقاً.
- manifest.json : تعريف التطبيق واسم التطبيق والأيقونات.
- sw.js : Service Worker للتثبيت والعمل مع قدر من التخزين المؤقت.
- icons/icon-192.png و icons/icon-512.png : أيقونات PWA.

طريقة الاستخدام:
1) ارفع كل الملفات والمجلدات كما هي إلى استضافة HTTPS.
2) افتح رابط الموقع وتأكد أنه يعمل.
3) افتح https://www.pwabuilder.com/ ثم أدخل رابط الموقع.
4) بعد أن يجتاز فحص PWA، استخدم خيار Android لتوليد حزمة Android.
5) قبل النشر، اختبر نسخة Android على الهاتف.

مهم:
- لا ترفع index.html أو souq-aljumla.html وحده؛ ارفع manifest.json وsw.js ومجلد icons أيضاً.
- يجب أن يكون الموقع HTTPS حتى تعمل ميزات PWA/Service Worker بشكل صحيح.
- طلبات Google Apps Script/Sheets لا يتم تخزينها في Service Worker.
- النسخة المستخدمة هنا هي نسخة souq-aljumla-google-sheets.html التي تحتوي على كود الربط الموجود مسبقاً.
